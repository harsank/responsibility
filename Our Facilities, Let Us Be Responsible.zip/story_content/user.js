function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6O74xX1MxtS":
        Script1();
        break;
      case "6RhNtnCsVEv":
        Script2();
        break;
  }
}

function Script1()
{
  //playAudio(‘Piano1.mp3’);
//load the scripts dynamically into the head of the document
function add_line() {
    var line = document.createElement("audio");
    var head=document.getElementsByTagName('body')[0];
    line.type = "audio/mp3";

    line.src="Piano1.mp3";
//line.src="https://d1490khl9dq1ow.cloudfront.net/music/mp3preview/de//ep-chill-full_z1IKi-Vd.mp3";
    line.id="bgSong" ;
	line.autoplay = true;
	line.loop = true;
    head.appendChild(line);
}

//but we only want to add these once!
if(document.getElementById('bgSong')==null){
	add_line();
var audio = document.getElementById('bgSong');

}
}

function Script2()
{
  // Name of the certificate html file
var certFilename = 'index.html';

// HTMLCollection of elements of type iFrame
var iframeElements = document.getElementsByTagName("iframe");

// Iterate over the iFrameElements HTMLCollection
for(var i = 0; i < iframeElements.length; i++){
    /* If src of current iFrame element equals the filename set in variable
	** certFilename call the generatePDF() function.
	*/
    var src = iframeElements[i].getAttribute('src');
	if (src.indexOf(certFilename) !=-1) {
		iframeElements[i].contentWindow.generatePDF();
	}
}
}

